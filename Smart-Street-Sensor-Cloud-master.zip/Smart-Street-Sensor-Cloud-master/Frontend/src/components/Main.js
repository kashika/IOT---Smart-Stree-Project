import React, {Component} from 'react';
import {Route} from 'react-router-dom';
import Login from './Login/Login';
import Home from './Home/Home';
import SensorHome from './Home/SensorHome';
import Delete from './Delete/Delete';
import Create from './CreateNode/Create';
import Navbar from './LandingPage/Navbar';
import MapContainer from './Maps/MapContainer';
import Graph from './Graphs/Graph'
import RelativeHumidityGraph from './Graphs/RelativeHumidityGraph'
import Wind from './Graphs/Wind'
import AddSensor from './AddSensor/AddSensor';
import ClusterMap from './Maps/ClusterMap';
import UpdateNode from './UpdateNode/UpdateNode';

//Create a Main Component
class Main extends Component {
    render(){
        return(
            <div>
                {/*Render Different Component based on Route*/}
                <Route path="/" component={Navbar}/>
                <Route path="/login" component={Login}/>
                <Route path="/home" component={Home}/>
                <Route path="/sensorhome" component={SensorHome}/>
                <Route path="/delete" component={Delete}/>
                <Route path="/create" component={Create}/>
                <Route path="/updatenode" component={UpdateNode}/>
                <Route path="/maps" component={MapContainer}/>
                <Route path="/graph" component={Graph}/>
                <Route path="/humiditygraph" component={RelativeHumidityGraph}/>
                <Route path="/windgraph" component={Wind}/>
                <Route path="/addsensor" component={AddSensor}/>
                <Route path="/clustermap" component={ClusterMap}/>
            </div>
        )
    }
}
//Export The Main Component
export default Main;