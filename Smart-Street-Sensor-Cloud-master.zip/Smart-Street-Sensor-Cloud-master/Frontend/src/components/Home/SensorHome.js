import React, {Component} from 'react';
import '../../App.css';
import axios from 'axios';
import cookie from 'react-cookies';
import {Redirect} from 'react-router';
import {Link} from 'react-router-dom';

import MapContainer from '../Maps/MapContainer';

class SensorHome extends Component {
    constructor(props){
        super(props);
		console.log("nodeid" + props.location.pathname.substring(12))
        this.state = {  
            sensors : [],
            nodeid : props.location.pathname.substring(12),
            redirectVar: null
        }
         this.deletesensor = this.deletesensor.bind(this); 
    }  
    //get the nodes data from backend  
    componentDidMount(){
        axios.get('http://localhost:3001/sensorhome/'+this.state.nodeid)
                .then((response) => {
                //update the state with the response data
                this.setState({
                    sensors : this.state.sensors.concat(response.data),
                });
            });
    }


    deletesensor = (id,e) => {
        //prevent page from refresh
        e.preventDefault();   
        console.log(id);
        //make a post request with the user data
        var url = 'http://localhost:3001/deletesensor/'
        var requesturl = url + id;
        axios.delete(requesturl)
            .then(response => {
                console.log("Status Code : ",response.status);  
                // console.log("Data: " + response.data);
                //  this.setState({
                //      redirectVar : <Redirect to="/home"/>
                //  })          
                  window.location = "/sensorhome/"+this.state.nodeid; 
            });         
    }


    render(){
        let redirectLink;
        //iterate over nodes to create a table row
        let details = this.state.sensors.map(sensor => {
            if(sensor.sensortype === "Temperature")
            {
                redirectLink = <td><Link to={`/graph/${sensor.sensorid}`} className = "btn btn-warning">Real-time Sensor Data</Link></td> 
            }
            else if(sensor.sensortype === "Humidity")
            {
                redirectLink = <td><Link to={`/humiditygraph/${sensor.sensorid}`} className = "btn btn-warning">Real-time Sensor Data</Link></td> 
            }
            else if(sensor.sensortype === "Wind")
            {
                redirectLink = <td><Link to={`/windgraph/${sensor.sensorid}`} className = "btn btn-warning">Real-time Sensor Data</Link></td> 
            }
            return(
                <tr>
                    <td>{sensor.sensorid}</td>
                    <td>{sensor.nodeid}</td>
                    <td>{sensor.sensortype}</td>
                    <td>{sensor.sensorstatus}</td> 
                    <td>{sensor.installation_date}</td>
                    <td><Link to="/addsensor/"$nodeid className = "btn btn-info">Update</Link></td> 
                    {redirectLink}
                    <td><button className = "btn btn-danger" onClick={this.deletesensor.bind(this,sensor.sensorid)} value={sensor.sensorid}>Delete</button></td> 
                    

                </tr>
            )
        })
        //if not logged in go to login page
        let redirectVar = null;
        let str = this.state.nodeid;
        // if(!cookie.load('cookie')){
        //     redirectVar = <Redirect to= "/login"/>
        // }
        return(
            <div>
                {this.state.redirectVar}
               
                <div className="container map-container col">
                {/* <MapContainer/>  */}
                </div>
                <div className="container">
                    <h3>Sensor List for Node ID {str}</h3>
                        <table className="table table-striped">
                            <thead>
                                <tr>
                                    <th>Sensor ID</th>
                                    <th>Node ID</th>
                                    <th>Sensor Type</th>
                                    <th>Sensor Status</th>
                                    <th>Installed On</th>
                                </tr>
                            </thead>
                            <tbody>
                                {/*Display the Tbale row based on data recieved*/}
                                {details}
                            </tbody>
                        </table>
                </div> 
            </div> 
        )
    }
}
//export Home Component
export default SensorHome;