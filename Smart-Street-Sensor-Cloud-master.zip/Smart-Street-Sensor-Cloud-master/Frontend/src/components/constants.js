export const MAP_CENTER_COORDINATES = [51.0, 19.0];
export const MAP_ZOOM = 4;
export const MAP_MAX_ZOOM = 18;
