var mongoose = require('mongoose');


// var SensorReadings = mongoose.model('SensorReadings',{
//     table :{
//         type : Object
//     },
    // columnNames :{
    //     type : Array
    // },
    // columnTypes :{
    //     type : Array
    // },
    // columnUnits :{
    //     type : Array
    // },
    // rows :{
    //     type : Array
    // },

    //======================
    Sensors = mongoose.model('Sensors',{
            sensorid :{
                type : String
             },
            sensortype : {
                type : String
             },
            sensorstatus : {
                type : String
            },
            installation_date : {
                type : String
            },
            nodeid : {
                type : String
            }
	
});

module.exports = {Sensors};