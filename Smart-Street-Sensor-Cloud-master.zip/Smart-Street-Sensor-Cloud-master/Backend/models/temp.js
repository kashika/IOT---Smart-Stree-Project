var mongoose = require('mongoose');

var TempReadings = mongoose.model('TempReadings',{
    sensorid : {
        type : String
    },
    values :{
        type : String
    },
    timestamp : {
        type : String
    },
    nodeid : {
        type : String
    },
    clusterid : {
        type : String
    },
    sensortype : {
        type : String
    },
    latitude : {
        type : String
    },
    longitude : {
        type : String
    }
});

module.exports = {TempReadings};