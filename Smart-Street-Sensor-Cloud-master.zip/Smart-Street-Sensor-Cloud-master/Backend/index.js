//import the require dependencies
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var session = require('express-session');
var request = require('request');
var cookieParser = require('cookie-parser');
var cors = require('cors');
var {Nodes} = require('./models/node');
var {Sensors} = require('./models/sensor')
var {TempReadings} = require('./models/temp')
var {HumidityReadings} = require('./models/humidity')
var {WindSpeedReadings} = require('./models/wind')
var {mongoose} = require('./db/mongoose');

app.set('view engine', 'ejs');

//use cors to allow cross origin resource sharing
app.use(cors({ origin: 'http://localhost:3000', credentials: true }));

//use express session to maintain session data
app.use(session({
    secret              : 'cmpe273_kafka_passport_mongo',
    resave              : false, // Forces the session to be saved back to the session store, even if the session was never modified during the request
    saveUninitialized   : false, // Force to save uninitialized session to db. A session is uninitialized when it is new but not modified.
    duration            : 60 * 60 * 1000,    // Overall duration of Session : 30 minutes : 1800 seconds
    activeDuration      :  5 * 60 * 1000
}));

// app.use(bodyParser.urlencoded({
//     extended: true
//   }));
app.use(bodyParser.json());

//Allow Access Control
app.use(function(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:3000');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Allow-Methods', 'GET,HEAD,OPTIONS,POST,PUT,DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers');
    res.setHeader('Cache-Control', 'no-cache');
    next();
  });

  var Users = [{
      username : "admin",
      password : "admin"
  }]

//Route to handle Post Request Call
app.post('/login',function(req,res){
    console.log("Inside Login Post Request");
    //console.log("Req Body : ", username + "password : ",password);
    console.log("Req Body : ",req.body);
    Users.filter(function(user){
        if(user.username === req.body.username && user.password === req.body.password){
            res.cookie('cookie',"admin",{maxAge: 900000, httpOnly: false, path : '/'});
            req.session.user = user;
            res.writeHead(200,{
                'Content-Type' : 'text/plain'
            })
            res.end("Successful Login");
        }
    })

    
});

//Route to get All Books when user visits the Home Page
app.get('/home', function(req,res){

    Nodes.find({
    }, function(err,nodelist){
        console.log("Inside node home")
        if (err) {
            console.log("err");
            res.code = "400";
            res.value = "Fetching node list failed";
            console.log(res.value);
            res.sendStatus(400).end(); 
        } else{
            console.log("success")
            res.code = "200";
            res.value = nodelist;
            console.log("Node list fetched" + JSON.stringify(nodelist));
            res.send(JSON.stringify(nodelist));
        }
    })
    
})

//Get data for all sensors 
//Route to get All Books when user visits the Home Page
app.get('/sensorhome/:nodeid', function(req,res){

    Sensors.find({
        nodeid : req.params.nodeid
    }, function(err,sensorlist){
        console.log("Inside sensor home")
        if (err) {
            console.log("err");
            res.code = "400";
            res.value = "Fetching sensor list failed";
            console.log(res.value);
            res.sendStatus(400).end(); 
        } else{
            console.log("success")
            res.code = "200";
            res.value = sensorlist;
            console.log("Sensor list fetched" + JSON.stringify(sensorlist));
            res.send(JSON.stringify(sensorlist));
        }
    })
    
})

//Create Post request
app.post('/create',function(req,res){
        console.log("Inside create node" + JSON.stringify(req.body.Latitude));
        var nodeid = req.body.NodeID
        var node_status = req.body.Status
        var lat = req.body.Latitude
        var long = req.body.Longitude
        var no_sensors = req.body.NoSensors
        var clusterid = req.body.ClusterID
        var installation_date = req.body.InstallationDate
        // var node = new Nodes({
        //     nodeid : req.body.NodeID,
        //     node_status : req.body.Status,
        //     lat : req.body.Latitude,
        //     long : req.body.Longitude,
        //     no_sensors : req.body.NoSensors,
        //     clusterid : req.body.ClusterID,
        //     installation_date : req.body.InstallationDate
        // })
        //console.log(node);
        //=============================
        // var apiurl = 'http://erddap.cencoos.org/erddap/tabledap/edu_dri_raws_cacsjo.json?latitude%2Clongitude%2Cstation%2Cwind_speed%2Csolar_radiation%2Cwind_from_direction%2Cbattery_voltage%2Clwe_thickness_of_precipitation_amount%2Cwind_speed_of_gust%2Cair_temperature_cm_time_mean'
        // request(apiurl, function(error,response,body){
        //     var parsedjson = JSON.parse(body);
        //     console.log(parsedjson.table.columnNames)
        //    // console.log(body)   

        //     var sensor = new SensorReadings({
        //         table : parsedjson.table
        //         // columnNames : parsedjson.table.columnNames,
        //         // columnTypes : parsedjson.table.columnTypes,
        //         // columnUnits : parsedjson.table.columnUnits,
        //         // rows : parsedjson.table.rows 
        //     });
        //     sensor.save().then((sensor) => {
        //       console.log("Sensor data added successfully : " + sensor)
        //     },(err) =>{
        //         console.log("Error in adding sensor data" + err)
        //     })
        // })
        //=====================================
        // node.save().then((node) => {
        //    // console.log("Node : " + node);
        //     res.code = "200";
        //     res.sendStatus(200).end();
        // },(err) =>{
        //     console.log("Error in adding node" + err)
        //     res.sendStatus(400).end();
        // })
        //=====================================
        Nodes.findOneAndUpdate(
            {nodeid: nodeid}, // find a document with that filter
            {
                $set : {
                    nodeid,
                    node_status,
                    lat,
                    long,
                    no_sensors,
                    clusterid,
                    installation_date
                }
            }, // document to insert when nothing was found
            {upsert: true, new: true, runValidators: true}, // options
            function (err, doc) { // callback
                if (err) {
                    // handle error
                    console.log(err);
                    res.code = "200";
                    res.sendStatus(400).end();
                } else {
                // handle document
                console.log("Sensor node updated " + doc);
                res.code = "200";
                res.body = doc;
                res.status(200).send(doc);
                }
            });

});

//Route to get All Books when user visits the Home Page
app.get('/sensorreadings', function(req,res){

    SensorReadings.find({
    }, function(err,sensorreadings){
        console.log("Inside sensor readings")
        if (err) {
            console.log("err");
            res.code = "400";
            res.value = "Fetching sensor readings data failed";
            console.log(res.value);
            res.sendStatus(400).end(); 
        } else{
            console.log("success")
            res.code = "200";
            res.value = sensorreadings;
            console.log("Sensor readings fetched" + JSON.stringify(sensorreadings[0]));
            res.send(sensorreadings[0]);
        }
    })
    
})

app.delete('/delete/:NodeID', function(req,res){
    console.log("Inside Delete" + req.params.NodeID);  
   
    Nodes.findOneAndDelete({
        nodeid : req.params.NodeID
    }, function (err, result) {

        if (err) {

            console.log("error in deleting");
            res.sendStatus(400).end();

        } else {

            console.log(result);
            res.sendStatus(200).end();

        }

    });


    });

//TESTING NEW CREATE SENSOR DATA
//Create Post request
app.post('/tempsensor',function(req,res){
   
    var tempreadings = new TempReadings({
        sensorid : req.body.sensorid,
        temp : req.body.temp,
        timestamp : req.body.timestamp,
    })
    
    tempreadings.save().then((tempreadings) => {
        console.log("Temp Readings : " + tempreadings);
        res.code = "200";
        res.sendStatus(200).end();
    },(err) =>{
        console.log("Error in temp data" + err)
        res.sendStatus(400).end();
    })

});

//Create Post request
app.post('/humiditysensor',function(req,res){
   
    var humidityreadings = new HumidityReadings({
        sensorid : req.body.sensorid,
        relativehumidity : req.body.relativehumidity,
        timestamp : req.body.timestamp,
    })
    
    humidityreadings.save().then((humidityreadings) => {
        console.log("Realtive Humidity % Readings : " + humidityreadings);
        res.code = "200";
        res.sendStatus(200).end();
    },(err) =>{
        console.log("Error in relative humidity data" + err)
        res.sendStatus(400).end();
    })

});

//Create Post request
app.post('/windsensor',function(req,res){
   
    var windspeedreadings = new WindSpeedReadings({
        sensorid : req.body.sensorid,
        windspeed : req.body.windspeed,
        timestamp : req.body.timestamp,
    })
    
    windspeedreadings.save().then((windspeedreadings) => {
        console.log("Wind Speed Readings : " + windspeedreadings);
        res.code = "200";
        res.sendStatus(200).end();
    },(err) =>{
        console.log("Error in wind speed data" + err)
        res.sendStatus(400).end();
    })

});

app.post('/addsensor',function(req,res){
    var sensorid = req.body.sensorid;
    var sensortype = req.body.sensortype;
    var installation_date = req.body.installation_date;
    var sensorstatus = req.body.sensorstatus;
    var nodeid = req.body.nodeid;
    console.log("sensorid" + req.body.sensorid)

        Sensors.findOneAndUpdate(
            {sensorid: sensorid}, // find a document with that filter
            {
                $set : {
                    sensorid,
                    sensortype,
                    installation_date,
                    sensorstatus,
                    nodeid
                }
            }, // document to insert when nothing was found
            {upsert: true, new: true, runValidators: true}, // options
            function (err, doc) { // callback
                if (err) {
                    // handle error
                    console.log(err);
                    res.code = "200";
                    res.sendStatus(400).end();
                } else {
                // handle document
                console.log("Sensor node updated " + doc);
                res.code = "200";
                res.body = doc;
                res.status(200).send(doc);
                }
            });
});


//Delete sensor
app.delete('/deletesensor/:SensorID', function(req,res){
    console.log("Inside Delete" + req.params.SensorID);  
   
    Sensors.findOneAndDelete({
        sensorid : req.params.SensorID
    }, function (err, result) {

        if (err) {
            console.log("error in deleting");
            res.sendStatus(400).end();

        } else {
            console.log(result);
            res.sendStatus(200).end();

        }

    });
    });

//start your server on port 3001
app.listen(3001);
console.log("Server Listening on port 3001");